![肥沃的田地](block:betterwithmods:fertile_farmland)

肥沃的田地能够加速农作物生长,对着田地或其上面的农作物使用骨粉即可
但肥料有可能会在随机的时间段之后被耗尽,除非你使用了 [培养皿](planter.md)

[HCBonemeal](../hardcore/index.md)：如果启用，则骨粉将只能用于肥沃田地而非直接催熟农作物